package com.ibm.apl2.exercise1;

import java.io.IOException;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ibm.apl2.*; 
import java.io.PrintWriter; 

/**
 * @version 	1.0
 * @author
 */
public class Exercise1Servlet extends HttpServlet {

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
			processRequest(req, resp); 
	}

	/**
	 * @param req
	 * @param resp
	 */
	private void processRequest(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		* Use the servlet?s request object to extract the parameters 
	  String String1 = req.getParameter("VALUE_1"); 
	  String String2 = req.getParameter("VALUE_2"); 
 
//		* Make sure they're not empty 
	  if (String1 == null) String1 = "0"; 
	  if (String2 == null) String2 = "0"; 
	  if (String1.compareTo("") == 0) String1 = "0"; 
	  if (String2.compareTo("") == 0) String2 = "0"; 
 
//		* Extract their numeric values 
	  double Value1 = 0; 
	  double Value2 = 0; 
	  try {Value1 = java.lang.Double.parseDouble(String1);} 
	  catch (NumberFormatException e) {} 
	  try {Value2 = java.lang.Double.parseDouble(String2);} 
	  catch (NumberFormatException e) {} 
 
//		* Calculate the average 
	  double Average = 0; 
	  Apl2interp Apl2 = null; 
	  try { 
	  Apl2 = new Apl2interp(); 
		Apl2object Vector = new Apl2object(Apl2, 
	  new double[]{ Value1, Value2 }); 
		Apl2.Associate("AVERAGE", 11, "AVERAGE"); 
		Apl2object Result = Apl2.Execute("AVERAGE", Vector); 
		Average = Result.doubleValue(); 
	  } 
	  catch (Apl2exception e) {} 
	  if (Apl2 != null) try {Apl2.Stop();} catch (Apl2exception e) {} 
 
//		* Use the response object to get a PrintWriter object 
//		* and build the HTML result. 
	  PrintWriter out = resp.getWriter(); 
	  out.println("<HTML>"); 
	  out.println("<HEAD><TITLE>Exercise 1 Average</TITLE></HEAD>"); 
	  out.println("<BODY>"); 
	  out.println("<P>"); 
	  out.println("Average: " + Average); 
	  out.println("</BODY>"); 
	  out.println("</HTML>"); 
	}

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
			processRequest(req, resp); 
	}

}

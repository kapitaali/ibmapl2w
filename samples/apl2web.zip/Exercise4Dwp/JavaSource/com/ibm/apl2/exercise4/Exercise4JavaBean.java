/*
 * Created on Aug 17, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibm.apl2.exercise4;

import java.io.Serializable;
import com.ibm.apl2.ejbs.Exercise4EJB; 
import com.ibm.apl2.ejbs.Exercise4EJBHome; 
import java.rmi.RemoteException; 
import java.util.Hashtable; 
import javax.ejb.CreateException; 
import javax.naming.Context; 
import javax.naming.InitialContext.*; 
import javax.naming.InitialContext; 
import javax.naming.NamingException; 

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Exercise4JavaBean implements Serializable {
	public double Average(double Value1, double Value2) { 
	  final String WEBSPHERE_FACTORY = 
		"com.ibm.websphere.naming.WsnInitialContextFactory"; 
	  final String LIBRARY_APP_NAMING_PROVIDER = 
		"corbaloc:iiop:localhost:2809"; 
	  final String JndiName = "ejb/com/ibm/apl2/ejbs/Exercise4EJBHome"; 
	  final String ClassName = "com.ibm.apl2.ejbs.Exercise4EJBHome"; 
 
	  double Average = 0; 
 
	  try { 
		Hashtable Environment = new Hashtable(); 
		Environment.put(Context.INITIAL_CONTEXT_FACTORY,  
		  WEBSPHERE_FACTORY); 
		Environment.put(Context.PROVIDER_URL,  
		  LIBRARY_APP_NAMING_PROVIDER); 
       
		javax.naming.InitialContext InitialContext = new  
		  InitialContext(Environment); 
 
		java.lang.Object RemoteObject =  
		  InitialContext.lookup(JndiName); 
       
		Class EjbClass = Class.forName(ClassName); 
		Exercise4EJBHome EjbHome = 
		  (Exercise4EJBHome) javax.rmi.PortableRemoteObject.narrow( 
			RemoteObject, 
			EjbClass); 
		Exercise4EJB Ejb = EjbHome.create(); 
		Average = Ejb.Average(new double[] { Value1, Value2 }); 
	  } catch (NamingException e) { 
		System.out.println("NamingException caught."); 
	  } catch (RemoteException e) { 
		System.out.println("RemoteException caught."); 
	  } catch (CreateException e) { 
		System.out.println("CreateException caught."); 
	  } catch (ClassNotFoundException e) { 
		System.out.println("ClassNotFoundException caught."); 
	  } 
	  return Average; 
	} 
}

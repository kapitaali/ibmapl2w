package com.ibm.apl2.exercise4;

import java.io.IOException;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @version 	1.0
 * @author
 */
public class Exercise4Servlet extends HttpServlet {

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
			processRequest(req, resp);
	}

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
			processRequest(req, resp); 
 	}
	private void processRequest( 
	  HttpServletRequest req, 
	  HttpServletResponse resp) 
	  throws ServletException, IOException { 
	  String String1 = req.getParameter("VALUE_1"); 
	  String String2 = req.getParameter("VALUE_2"); 
 
	  //* Make sure they're not empty 
	  if (String1 == null) String1 = "0"; 
	  if (String2 == null) String2 = "0"; 
	  if (String1.compareTo("") == 0) String1 = "0"; 
	  if (String2.compareTo("") == 0) String2 = "0"; 
 
	  //* Extract their numeric values 
	  double Value1 = 0; 
	  double Value2 = 0; 
	  try { 
		Value1 = java.lang.Double.parseDouble(String1); 
	  } catch (NumberFormatException e) {} 
	  try { 
		Value2 = java.lang.Double.parseDouble(String2); 
	  } catch (NumberFormatException e) {} 
 
	  //* Use a Java Bean to calculate the average 
	  Exercise4JavaBean Bean = new Exercise4JavaBean(); 
	  double Average = Bean.Average(Value1, Value2); 
 
	  //* Save the result in the request object 
	  req.setAttribute("Average", new Double(Average)); 
 
	  //* Forward request to the JSP for output formatting 
   
   
	  getServletContext().getRequestDispatcher("Exercise4JSP.jsp"
	).forward(  req, resp); 
	} 
}

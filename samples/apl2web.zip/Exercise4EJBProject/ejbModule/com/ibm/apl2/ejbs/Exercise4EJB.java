package com.ibm.apl2.ejbs;
/**
 * Remote interface for Enterprise Bean: Exercise4EJB
 */
public interface Exercise4EJB extends javax.ejb.EJBObject {
	public double Average(double[] Array) throws java.rmi.RemoteException;
}

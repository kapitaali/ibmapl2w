package com.ibm.apl2.ejbs;
/**
 * Home interface for Enterprise Bean: Exercise4EJB
 */
public interface Exercise4EJBHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: Exercise4EJB
	 */
	public com.ibm.apl2.ejbs.Exercise4EJB create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}

package com.ibm.apl2.ejbs;
import com.ibm.apl2.*; 
/**
 * Bean implementation class for Enterprise Bean: Exercise3EJB
 */
public class Exercise3EJBBean implements javax.ejb.SessionBean {
	private javax.ejb.SessionContext mySessionCtx;
	private Apl2interp Slave = null; 
	private Apl2object Function = null; 
	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
		Slave = null; 
		try { 
		  Slave = new Apl2interp(); 
		  Function = new Apl2object(Slave, "AVERAGE"); 
		  Slave.Associate("AVERAGE", 11, Function); 
		} catch (Apl2exception Exception) { 
		  if (Slave != null) { 
			try { 
			  Slave.Stop(); 
			} catch (Apl2exception StopException) { 
			} 
			Slave = null; 
		  } 
		  throw new javax.ejb.CreateException( 
			"Unable to initialize APL2 environment"); 
		} 
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
		try { 
		  Function.Free(); 
		  Slave.Stop(); 
		} catch (Apl2exception Exception) { 
		} 
	}
	public double Average(double[] Array) { 
	double Result = 0; 
	  try { 
		Apl2object aplintArray = new Apl2object(Slave, Array); 
		Apl2object aplAverage = Slave.Execute(Function,  
		  aplintArray); 
		aplintArray.Free(); 
		Result = aplAverage.doubleValue(); 
		aplAverage.Free(); 
	  } catch (Apl2exception e) { 
		System.out.println("Apl2exception caught"); 
		System.out.println("Exception message: " +  
		  e.getMessage()); 
		System.out.println("Event: " + e.Type + " " + e.Code); 
	  } 
	  return Result; 
	} 
}

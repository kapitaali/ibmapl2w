package com.ibm.apl2.ejbs;
/**
 * Home interface for Enterprise Bean: Exercise3EJB
 */
public interface Exercise3EJBHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: Exercise3EJB
	 */
	public com.ibm.apl2.ejbs.Exercise3EJB create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
